export const changeVisit = (id: number) => ({
    type: 'CHANGE_VISIT',
    payload: id,
});